﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Diagnostics;


namespace Diplomas.aspx
{
    public partial class gafets : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Visible = false;
        }
        public void imagen()
        {
            //cargar imagen a servidor
            if (FileUpload1.HasFile)
            {
                string nombrearchivo = FileUpload1.FileName;
                string ruta = "/Recursos/" + nombrearchivo;
                FileUpload1.SaveAs(Server.MapPath(ruta));
                Label1.Text = ruta;
                Label1.Visible = true;
            }
        }
        public void metodo2()
        {
            Document pdfDoc = new Document(PageSize.LETTER);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.AddTitle("Gafets");
            pdfDoc.AddCreator("Ale Larregui");
            pdfDoc.Open();
            //alineacion y creacion de elemento paragraph
            Paragraph nombre = new Paragraph(TextBox1.Text);
            nombre.Alignment = Element.ALIGN_CENTER;
            nombre.Font.Size = Convert.ToInt16(tamanioletra.Text);
            nombre.Font = FontFactory.GetFont("Arial", Convert.ToInt16(posiciontext.Text));
            nombre.Font.SetStyle(Font.BOLD);


            //agregar imagen 
            string imagen = Server.MapPath(".") + Label1.Text;
            //string imageFilePath = Server.MapPath(".") + "/Recursos/gafets.png";
            iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(imagen);
            img.Alignment = iTextSharp.text.Image.UNDERLYING;
            img.SetAbsolutePosition(Convert.ToInt16(TextBox2.Text), Convert.ToInt16(TextBox3.Text));



            //añade al documento
            pdfDoc.Add(img);
            pdfDoc.Add(nombre);


            //cierre y abrir pdf
            pdfDoc.Close();
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;" + "filename=gafets.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Write(pdfDoc);
            Response.End();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {

            metodo2();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            imagen();
        }
    }
}