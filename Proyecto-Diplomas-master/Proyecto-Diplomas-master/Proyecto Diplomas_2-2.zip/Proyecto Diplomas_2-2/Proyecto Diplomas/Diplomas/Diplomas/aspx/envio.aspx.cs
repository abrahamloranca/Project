﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace enviodiploma
{
    public partial class envio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(FileUpload1.HasFile)
            {
                String ext = System.IO.Path.GetExtension(FileUpload1.FileName);
                if (ext == ".pdf")
                {
                    String path = Server.MapPath("../pdf//");
                    FileUpload1.SaveAs(path + "diploma.pdf");
                }
                else
                {
                    Response.Write("<h3> porfavor selecciona un PDF");
                }
            }
            else
            {
                Response.Write("<h3> porfavor selecciona un archivo");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
           // string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "@\pdf\diploma.jpg";
            //Bitmap image = new Bitmap(path,true);

            //Bitmap bmp = Properties.Resources.factura;
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            Response.Redirect("../Index.aspx");
        }
    }
}