﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

namespace Diplomas.aspx
{
    
    public partial class EditarEliminar : System.Web.UI.Page
    {
        string cadena="Server=127.0.0.1; Database=proyecto_enviodiploma; uid=root;";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }
        private void BindData()
        {
            DataTable dt = new DataTable();
            using (MySqlConnection cn = new MySqlConnection(cadena))
            {
                MySqlDataAdapter adp = new MySqlDataAdapter("SELECT Nombre,ApellidoP,ApellidoM,CorreoEle,Folio_alumno FROM alumnos ", cn);
                adp.Fill(dt);
                if(dt.Rows.Count>0)
                {
                    Modificar.DataSource = dt;
                    Modificar.DataBind();
                }
            }
        }

        protected void Modificar_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int id = int.Parse(Modificar.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtnombre = (TextBox)Modificar.Rows[e.RowIndex].FindControl("txtnombre");
            TextBox txtapellidop = (TextBox)Modificar.Rows[e.RowIndex].FindControl("txtapellidop");
            TextBox txtapellidom = (TextBox)Modificar.Rows[e.RowIndex].FindControl("txtapellidom");
            TextBox txtcorreo = (TextBox)Modificar.Rows[e.RowIndex].FindControl("txtcorreo");
            UpdateProduct(id, txtnombre.Text, txtapellidop.Text, txtapellidom.Text, txtcorreo.Text);
            Modificar.EditIndex = -1;
            BindData();
           
        }

        protected void Modificar_RowEditing(object sender, GridViewEditEventArgs e)
        {
            Modificar.EditIndex = e.NewEditIndex;
            BindData();
        }

        protected void Modificar_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id =int.Parse( Modificar.DataKeys[e.RowIndex].Value.ToString());
            delateprodut(id);
            BindData();
        }

        protected void Modificar_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            Modificar.EditIndex = -1;
            BindData();

        }
        private void UpdateProduct(int id,string Nombre,string ApellidoP,string ApellidoM,string CorreoEle)
        {
            using (MySqlConnection cn = new MySqlConnection(cadena))
            {
                String query = "UPDATE alumnos SET Nombre='" + Nombre + "',ApellidoP='" + ApellidoP + "',ApellidoM='" + ApellidoM + "',CorreoEle='" + CorreoEle + "' WHERE Folio_alumno=" + id + "";
                MySqlCommand cmd = new MySqlCommand(query, cn);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }
        private void delateprodut(int id)
        {
            using (MySqlConnection cn = new MySqlConnection(cadena))
            {
                String query = "DELETE FROM alumnos WHERE Folio_alumno=" + id + "";
                MySqlCommand cmd = new MySqlCommand(query, cn);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}