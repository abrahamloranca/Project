﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Diplomas.aspx
{
    public partial class Modificacion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnBus_Click(object sender, EventArgs e)
        {
            Diplomas.Models.Conexion selecciona = new Diplomas.Models.Conexion();
            SqlDataAdapter adapter;
            DataRow fila;

            if (selecciona.AbrirConexion())
            {
                adapter = selecciona.construye_adapter("select * from Persona where IdPersona = @IdPersona");

                adapter.SelectCommand.Parameters.Add(new SqlParameter("@IdPersona", SqlDbType.Int));
                adapter.SelectCommand.Parameters["@IdPersona"].Value = txtId.Text;

                fila = selecciona.extrae_registro(adapter);
                if (fila != null)
                {
                    txtnom.Text = fila["Nombre"].ToString();
                    txtapp.Text = fila["App"].ToString();
                    txtapm.Text = fila["Apm"].ToString();
                    txtFec.Text = fila["FechaN"].ToString();
                    txtOc.Text = fila["Ocupacion"].ToString();
                    txtIdE.Text = fila["IdEve"].ToString();
                    txtCor.Text = fila["Correo"].ToString();




                }
                else Response.Write("Error al visualizar el registro");
            }
            else Response.Write("Error al conectar a la base de datos");
        }


       
        protected void BtnMod_Click(object sender, EventArgs e)
        {
            Diplomas.Models.Manejo ma = new Models.Manejo();

            int re = ma.Actualiza();
            if (re == 1)
                Response.Write("Actualizado");
            else if (re == 0)
                Response.Write("No actualizado");
            else
                Response.Write("Error");


           
        }

        protected void btnEli_Click(object sender, EventArgs e)
        {
            SqlCommand MyCommand;
            Diplomas.Models.Conexion elimina = new Diplomas.Models.Conexion();

            if (txtId.Text != "")
            {
                if (elimina.AbrirConexion())
                {
                    MyCommand = elimina.construye_command("Delete from Persona where IdPersona = @IdPersona");
                    MyCommand.Parameters.Add(new SqlParameter("@IdPersona", SqlDbType.Int, 10));
                    MyCommand.Parameters["@IdPersona"].Value = txtId.Text;



                    if ((elimina.ejecutanonquery()) != 0)
                    {
                        Response.Write("Registro Eliminado");

                    }
                    else
                        Response.Write("No se afectaron registros");

                    MyCommand.Connection.Close();
                    elimina.desconectar();
                }
            }
            else Response.Write("Ingrese el Id para poder realizar la eliminacion ");

            txtId.Text = "";
            txtapm.Text = "";
            txtapp.Text = "";
            txtCor.Text = "";
            txtFec.Text = "";
            txtIdE.Text = "";
            txtnom.Text = "";
            txtOc.Text = "";
        }

      
    }// end class
}