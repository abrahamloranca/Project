﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace proyecto01_diplomas
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void envia_Click(object sender, EventArgs e)
        {
            ClientScript.RegisterStartupScript(GetType(), "verifica", "Operacion();", true);


           /*/ string nombres, apellidopa, apellidoma, correoe;
            int universidad;
            nombres = nombre.Text;
            apellidopa = apellidop.Text;
            apellidoma = apellidom.Text;
            correoe = email.Text;




            MySqlCommand Commando;



            Diplomas.Models.Conexion Insertar = new Diplomas.Models.Conexion();

            int regresa = 0;
            if (Insertar.AbrirConexion())
            {
                string cad_comando = "insert into alumnos(Nombre, ApellidoP, ApellidoM, CorreoEle)" + "values ('" + nombres + "','" + apellidopa + "','" + apellidoma + "','" + correoe + "',')";
                Commando = Insertar.construye_command(cad_comando);

                if (Insertar.ejecutanonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Commando.Connection.Close();
                Insertar.desconectar();
            }
            else
                regresa = -1;

/*/

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string nombres = nombre.Text+" "+apellidop.Text+" "+ apellidom.Text;
            Diplomas.Models.Conexion registro = new Diplomas.Models.Conexion();
            DateTime fecha = Convert.ToDateTime(date.Text);
            registro.Altas(Convert.ToInt32( curp.Text),nombre.Text, apellidop.Text, apellidom.Text,fecha,ocupacion.Text,Convert.ToInt32(idevento.Text),email.Text);
            registro.insertnombrecorreo(nombres, email.Text);
        }

        protected void Regresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("../Index.aspx");
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {

        }

    }
}