﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Word = Microsoft.Office.Interop.Word;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace Diplomas.aspx
{
    public partial class EnvioDiplomas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            /*Diplomas.Models.Conexion cargarcombo = new Models.Conexion();
            cargarcombo.mandararreglos(ListBox1);*/
        }

        protected void Alumnos_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Enviar_Click(object sender, EventArgs e)
        {
            Diplomas.Models.Conexion con = new Diplomas.Models.Conexion();
            int pos = con.repos();
            string[]  nombres = new string[20];
            string[] correo = new string[20];
            nombres = con.devolvernombre();
            correo = con.devolvercorreo();
           for(int i = 0; i < pos; i++) { 
            string email, asunto, mensaje;
            email = correo[i];
            asunto = "Diploma";
            mensaje = "Felicidades";
            string ruta=Server.MapPath("~/pdf/diplomas.pdf");
                String pathin = MapPath("~/pdf/diploma.pdf");
                String pathout = MapPath("~/pdf/diplomas.pdf");
                var doc = new Document(PageSize.A4);
                PdfReader reader = new PdfReader(pathin);
                reader.SelectPages("1");
                PdfStamper stamper = new PdfStamper(reader, new FileStream(pathout, FileMode.Create));
                PdfContentByte pbover = stamper.GetOverContent(1);
                Font letra = new Font(Font.FontFamily.TIMES_ROMAN,Convert.ToInt16(TextBox3.Text));
                ColumnText.ShowTextAligned(pbover, Element.ALIGN_JUSTIFIED, new Phrase(Convert.ToInt16(TextBox3.Text), nombres[i], letra), Convert.ToInt16(TextBox1.Text), Convert.ToInt16(TextBox2.Text), 0);
                stamper.Close();
                reader.Dispose();
                Diplomas.Models.Citas diplomaenvio = new Diplomas.Models.Citas(email, asunto, mensaje, ruta);
            }
        }



        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
            
                String ext = System.IO.Path.GetExtension(FileUpload1.FileName);
                if (ext == ".pdf")
                {
                    String path = Server.MapPath("../pdf//");
                    FileUpload1.SaveAs(path + "diploma.pdf");
                }
                else
                {
                    Response.Write("<h3> porfavor selecciona un PDF");
                }
            }
            else
            {
                Response.Write("<h3> porfavor selecciona un archivo");
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string ruta = Server.MapPath("~/pdf/diplomas.pdf");
            String pathin = MapPath("~/pdf/diploma.pdf");
            String pathout = MapPath("~/pdf/diplomas.pdf");
            var doc = new Document(PageSize.A4);
            PdfReader reader = new PdfReader(pathin);
            reader.SelectPages("1");
            PdfStamper stamper = new PdfStamper(reader, new FileStream(pathout, FileMode.Create));
            PdfContentByte pbover = stamper.GetOverContent(1);
            Font letra = new Font(Font.FontFamily.TIMES_ROMAN, Convert.ToInt16(TextBox3.Text));
            ColumnText.ShowTextAligned(pbover, Element.ALIGN_JUSTIFIED, new Phrase(Convert.ToInt16(TextBox3.Text),"Aqui Iria El Nombre", letra),Convert.ToInt16(TextBox1.Text),Convert.ToInt16(TextBox2.Text), 0);
            stamper.Close();
            reader.Dispose();
        }
    }
}