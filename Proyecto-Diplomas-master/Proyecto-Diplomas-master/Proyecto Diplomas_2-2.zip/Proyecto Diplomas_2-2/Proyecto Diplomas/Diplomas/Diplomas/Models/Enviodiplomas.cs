﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Mail;

namespace Diplomas.Models
{
    public class Citas
    {
        Boolean estado = true;
        String merror;
        public Citas(String destinatario, String asunto, String mensaje, string ruta)
        {
            MailMessage Correo = new MailMessage();
            SmtpClient protocolo = new SmtpClient();

            Correo.To.Add(destinatario);
            Correo.From = new MailAddress("cabresto105@gmail.com", "Abraham Loranca Rosas", System.Text.Encoding.UTF8);
            Correo.Subject = asunto;
            Correo.SubjectEncoding = System.Text.Encoding.UTF8;
            Correo.Body = mensaje;
            Correo.BodyEncoding = System.Text.Encoding.UTF8;
            Correo.IsBodyHtml = false;
            if (ruta.Equals("") == false)
            {
                System.Net.Mail.Attachment archivo = new System.Net.Mail.Attachment(ruta);
                Correo.Attachments.Add(archivo);
            }


            protocolo.Credentials = new System.Net.NetworkCredential("cabresto105@gmail.com", "prueba123456");
            protocolo.Port = 587;
            protocolo.Host = "smtp.gmail.com";
            protocolo.EnableSsl = true;

            try
            {
                protocolo.Send(Correo);
                protocolo.Dispose();
                Correo.Dispose();
            
            }
            catch (SmtpException error)
            {
                estado = false;
                merror = error.Message.ToString();
            }
           

        }
        public Boolean Estado
        {
            get { return estado; }

        }
        public string Mensaje_Error
        {
            get { return merror; }
        }
       
      
    }
}