﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace Diplomas.Models
{
    public class Manejo
    {
        public int Id { set; get; }
        public string nombre { set; get; }
        public  string app { set; get; }
        public string apm { set; get; }
        public string correo { set; get; }
        public string fec { set; get; }
        public int IdE { set; get; }
        public string ocu { set; get; }
        public int Actualiza() {

            SqlCommand comando;
            Diplomas.Models.Conexion actualizar = new Diplomas.Models.Conexion();
            int regresa = 0;
            if (actualizar.AbrirConexion())
            {
                comando = actualizar.construye_command("update Persona set IdPersona =" + Id + ", Nombre = '" + nombre + "', App = '" + app + "', Apm = '" + apm + "', FechaN ='" + fec + "', Ocupacion = '" + ocu + "', IdEve = " + IdE + ", Correo = '" + correo + "'  where IdPersona = " + Id);
                if (actualizar.ejecutanonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                actualizar.desconectar();
            }

            regresa = -1;
            return regresa;
        }


        public int Elimina()
        {

            SqlCommand comando;
            Diplomas.Models.Conexion eliminar = new Diplomas.Models.Conexion();
            int regresa = 0;
            if (eliminar.AbrirConexion())
            {
                comando = eliminar.construye_command("Delete from Persona where IdPersona ="+ Id);
                comando.Parameters.Add(new SqlParameter("@IdPersona", SqlDbType.Int, 10));
                comando.Parameters["@IdPersona"].Value = Id;
                if (eliminar.ejecutanonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;

                comando.Connection.Close();
                eliminar.desconectar();
            }

            regresa = -1;
            return regresa;
        }


    }
}