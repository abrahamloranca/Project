﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Web.UI.WebControls;

namespace Diplomas.Models
{
    public class Conexion
    {
        public SqlConnection carretera;
        public SqlCommand cadena_Acc;
        public SqlDataReader dr;
        string cadena = (@"Data Source=DESKTOP-VIPLUJ9; Initial Catalog=proyecto-enviodiplomas;Integrated Security=True");
       public static  int pos=0;
        public static string[] correos = new string[20];
       public static string[] nombres = new string[20];
        private SqlDataAdapter adapt;
        public bool AbrirConexion()
        {

          
            carretera = new SqlConnection(@"Data Source=DESKTOP-VIPLUJ9; Initial Catalog=proyecto-enviodiplomas;Integrated Security=True");

            try
            {

                carretera.Open();
             
                return true;

            }
            catch (Exception s)
            {

                s.ToString();
                carretera = null;
                return false;


            }

        }


        public void desconectar()
        {
            carretera.Close();
        }



        //****************METODOS DE CONSTRUCCION DE COMANDOS*****************
        public SqlCommand construye_command(string cadena)
        {
            cadena_Acc = new SqlCommand(cadena, carretera);

            return (cadena_Acc);
        }
        public int ejecutanonquery()
        {
            int afectados;
            try
            {
                afectados = cadena_Acc.ExecuteNonQuery();
                return (afectados);
            }
            catch (Exception oEx)
            {
                oEx.ToString();
                return (0);
            }
        }

        public DataRow extrae_registro(SqlDataAdapter adapter)
        {
            DataSet ds = new DataSet();
            DataRow fila;

            try
            {
                adapter.Fill(ds, "Elementos");

                DataTable mitabla = ds.Tables["Elementos"];


                fila = mitabla.Rows[0];
                return (fila);
            }
            catch (Exception oEx)
            {
                oEx.ToString();
                return (null);
            }
        }

        public DataSet consultarDataSet(string consulta)
        {
            DataSet ds = new DataSet();
            SqlCommand commando = new SqlCommand();
            SqlDataAdapter adapter = new SqlDataAdapter();
            commando.CommandText = consulta;
            commando.Connection = carretera;
            adapter.SelectCommand = commando;

            try
            {
                adapter.Fill(ds);
                return ds;
            }
            catch (Exception error)
            {
                error.ToString();
                return null;
            }
        }




        public SqlDataAdapter construye_adapter(string cadena)
        {
            adapt = new SqlDataAdapter(cadena, carretera);
            return (adapt);
        }



        public void construye_reader(string cadena)
        {

            cadena_Acc = new SqlCommand();
            cadena_Acc.Connection = carretera;
            cadena_Acc.CommandText = cadena;
            cadena_Acc.CommandType = CommandType.Text;
        }


        public SqlDataReader ejecuta_reader()
        {
            try
            {

                dr = cadena_Acc.ExecuteReader();
                return dr;
            }
            catch (Exception oEx)
            {
                oEx.ToString();
                return null;

            }
        }
        public void Altas(int id, string Nombre, string Apellidop, string ApellidoM, DateTime Fecha, string ocupacion, int eve, string correo)
        {
            SqlConnection dbconexion = new SqlConnection(cadena);
            string comando = "insert into Persona values('"+ id +"','" + Nombre + "','" + Apellidop + "','" + ApellidoM +"','"+ Fecha +"','" + ocupacion + "','" + eve + "','"+correo+"')";
            SqlCommand comand = new SqlCommand(comando, dbconexion);
            dbconexion.Open();
            comand.ExecuteNonQuery();
            dbconexion.Close();
        }
        /* public void mandararreglos(ListBox combo)
         {
             string[] nombres = new string[5];
             SqlConnection dbconexion = new SqlConnection(cadena);
             string comando = "select Nombre,App,Apm from Persona order by App";

             SqlCommand comand = new SqlCommand(comando, dbconexion);
             dbconexion.Open();
             SqlDataReader dr = comand.ExecuteReader();
             if (dr.HasRows)
             {
                 while (dr.Read())
                 {
                     combo.Items.Add(dr.GetString(1) + " " + dr.GetString(2) + " " + dr.GetString(0));
                 }
                 dr.Close();
             }
         }*/
        public void insertnombrecorreo(string nombre,string correo)
        {
          
           
            nombres[pos] = nombre;
            correos[pos] = correo;
            pos++;
        }
        public string[] devolvernombre()
        {
            return nombres;
        }
        public string[] devolvercorreo()
        {
            return correos;
        }
        public int repos()
        {
            return pos;
        }





    }
}