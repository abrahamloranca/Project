﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace diseño
{
    public partial class diseñoform : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("../index.aspx");
        }

        protected void enviar_Click(object sender, EventArgs e)
        {
          
          ClientScript.RegisterStartupScript(GetType(), "verifica", "Operacion();",true);
            
           
            string nombres, apellidopa, apellidoma, correoe;
            int universidad;
            nombres = nombre.Text;
            apellidopa = apellidop.Text;
            apellidoma = apellidom.Text;
            universidad = Convert.ToInt16( university.Text);
            correoe = email.Text;

            
            
           
            SqlCommand Commando;



            Diplomas.Models.Conexion Insertar = new Diplomas.Models.Conexion();

            int regresa = 0;
            if (Insertar.AbrirConexion())
            {
                string cad_comando = "insert into alumnos(Nombre, ApellidoP, ApellidoM, CorreoEle, Universidad_id)" + "values ('" + nombres + "','" + apellidopa + "','" + apellidoma + "','" + correoe + "','" + universidad + "')";
                Commando = Insertar.construye_command(cad_comando);

                if (Insertar.ejecutanonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Commando.Connection.Close();
                Insertar.desconectar();
            }
            else
                regresa = -1;
            

        }



    }
}