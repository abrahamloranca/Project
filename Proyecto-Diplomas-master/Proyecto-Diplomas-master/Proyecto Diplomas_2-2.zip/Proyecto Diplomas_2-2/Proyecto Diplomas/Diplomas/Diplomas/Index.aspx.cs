﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Diplomas
{
    public partial class Index : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
           Response.Redirect("aspx/Registros.aspx");
        }


        public bool Autenticar(string usuario, string password)
        {
            Diplomas.Models.Conexion Insertar = new Diplomas.Models.Conexion();

            //consulta a la base de datos
            string sql = @"SELECT COUNT(*) FROM Administrador WHERE Usuario = @user AND Contra = @pass";
            //cadena conexion

            Insertar.AbrirConexion();

            SqlCommand cmd = new SqlCommand(sql, Insertar.carretera); //ejecutamos la instruccion
            cmd.Parameters.AddWithValue("@user", usuario); //enviamos los parametros
            cmd.Parameters.AddWithValue("@pass", password);

            int count = Convert.ToInt32(cmd.ExecuteScalar()); //devuelve la fila afectada

            if (count == 0)
                return false;
            else
                return true;



        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            // MySqlConnection cn = new MySqlConnection("Server=127.0.0.1; Database=proyecto_enviodiploma; uid=root;");
            //string query= "SELECT * FROM administrador where user='" + user.Text + "' and pass='" + pass.Text + "'";

            //     MySqlCommand cmd = new MySqlCommand(query,cn);
            // cn.Open();
            // cmd.ExecuteNonQuery();
            //     DataTable dt = new DataTable();
            //     MySqlDataAdapter da =new MySqlDataAdapter(cmd);
            //     da.Fill(dt);
            //     foreach(DataRow dr in dt.Rows)
            //     {

            //         Response.Redirect("aspx/Adminpanel.aspx");
            //     }
            //     cn.Close();


            //     lbluser.Text = "Contraseña o usuario incorrectos";


            Diplomas.Models.Conexion Insertar = new Diplomas.Models.Conexion();




            if (user.Text != "" && pass.Text != "")
            {




                if (Autenticar(user.Text, pass.Text) == true)
                    Response.Redirect("aspx/Adminpanel.aspx");

                else
                {

                    Response.Write("Error de autenticacion");

                }

            }
            else
                Response.Write("Ingrese Usuario y contraseña");

        }// end btnIngresa

        }// end class
    }